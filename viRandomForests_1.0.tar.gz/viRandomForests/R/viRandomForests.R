"viRandomForests" <-
function(x, ...)
  UseMethod("viRandomForests")
